﻿@echo off
setlocal
chcp 65001 >nul
title HOJA Board 1.66.34 - Installer
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0INSTALL_HOJA_BOARD.ps1"
set "result=%errorlevel%"
echo.
if "%result%"=="0" (
  echo Installation finished. Check your desktop for the HOJA Board shortcut.
) else (
  echo Installation did not complete. Read the error shown above.
)
echo.
pause
exit /b %result%
