﻿# HOJA Board 1.66.33 - manually provisioned R8 installer (Windows PowerShell 5.1)
# Tested by static review only; the signed publisher, not this wrapper, defines the program bytes.
# Preserves user data; downloads pinned, signed program snapshots, and installs in LocalAppData.
param([switch]$NoShortcut)
$ErrorActionPreference = 'Stop'
Set-StrictMode -Version 2.0

$Version = '1.66.33'
$ManifestPayloadSha = 'ad2164eb3148868fbdaea01f9c7ede3adb423a93e87827f7d1621c2bd25af09d'
$RepoCommit = '52b3e5cd0448523f76f73a5813e52dd597296b3c'
$BootstrapCommit = '734e494fad3c81033a786b4b7a5acc5c3ebcd424'
$FeedRoot = 'https://xkdtndbrwk111-prog.github.io/teacher-tools/stable/runtime-v1/'
$FallbackRoot = 'https://raw.githubusercontent.com/xkdtndbrwk111-prog/teacher-tools/' + $RepoCommit + '/stable/runtime-v1/'
$BootstrapRoot = 'https://raw.githubusercontent.com/xkdtndbrwk111-prog/teacher-tools/' + $BootstrapCommit + '/tools/r8-updater/runtime/'
$PublicKeyXml = '<RSAKeyValue><Modulus>uJWav5jiIgqwKanGoBnw1QWyhpxsyjkWu8l2RdlxipSygIpnJk2eWHUT5B88i+3fOAvo72NYaEtNZYLkmCVue0Ex2tzzPa9VAgbMyer0VxG2Mort6P2qGilNu3hX0wgtgUbJC5ee75MOO0bUTUwoZRiSnDoWif5c8JCvM6ALvYskFbVkHjqP9ydpcMGura726q1wLLD7Iw+DtQgWP9g083VN+fhFFd2+z/lfmHkR8ljwkBrFbMwpHnEYU8oblcS0gkq/Es/9pldZ7idrG8iYxiXim68594CZBzvoMo9G5/axig/9A/pxrG23fP7posJBvN7ZF4vKRQqkEp/E1swZ7Q==</Modulus><Exponent>AQAB</Exponent></RSAKeyValue>'
$MaxTotal = 67108864
$MaxFile = 16777216
$Destination = Join-Path $env:LOCALAPPDATA 'TeacherToolsLocal'
$Pending = Join-Path $Destination 'hoja-manual-install.pending.json'
$Working = Join-Path $env:TEMP ('HOJA-Board-Installer-' + [guid]::NewGuid().ToString('N'))

function Hash-Bytes([byte[]]$Bytes, [string]$Algorithm) {
    $hasher = [Security.Cryptography.HashAlgorithm]::Create($Algorithm)
    if (-not $hasher) { throw ('Cannot create ' + $Algorithm + ' hash provider.') }
    try { return ([BitConverter]::ToString($hasher.ComputeHash($Bytes))).Replace('-', '').ToLowerInvariant() }
    finally { $hasher.Dispose() }
}
function Hash-File([string]$Path) {
    return Hash-Bytes ([IO.File]::ReadAllBytes($Path)) 'SHA256'
}
function Git-Blob-Sha([byte[]]$Bytes) {
    $header = [Text.Encoding]::ASCII.GetBytes(('blob ' + $Bytes.Length + [char]0))
    $joined = New-Object byte[] ($header.Length + $Bytes.Length)
    [Array]::Copy($header, 0, $joined, 0, $header.Length)
    [Array]::Copy($Bytes, 0, $joined, $header.Length, $Bytes.Length)
    return Hash-Bytes $joined 'SHA1'
}
function Assert-Plain([string]$Path) {
    if (Test-Path -LiteralPath $Path) {
        $item = Get-Item -LiteralPath $Path -Force
        if (($item.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0) {
            throw ('Symbolic link or junction is not allowed: ' + $Path)
        }
    }
}
function Get-Remote([string]$Url, [int]$Limit) {
    if ($Url -cnotmatch '^https://(xkdtndbrwk111-prog\.github\.io|raw\.githubusercontent\.com)/') {
        throw 'Unapproved download origin.'
    }
    [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
    $req = [Net.HttpWebRequest]::Create($Url)
    $req.AllowAutoRedirect = $false
    $req.Timeout = 20000
    $req.ReadWriteTimeout = 20000
    $req.UserAgent = 'HOJA-Board-Manual-Installer/1.66.33'
    $req.Headers['Cache-Control'] = 'no-cache'
    $response = $null
    $stream = $null
    $ms = New-Object IO.MemoryStream
    try {
        $response = $req.GetResponse()
        if ([int]$response.StatusCode -ne 200 -or $response.ContentLength -gt $Limit) {
            throw ('Invalid download response: ' + $Url)
        }
        $stream = $response.GetResponseStream()
        $buffer = New-Object byte[] 32768
        while (($count = $stream.Read($buffer, 0, $buffer.Length)) -gt 0) {
            if ($ms.Length + $count -gt $Limit) { throw 'Download size limit exceeded.' }
            $ms.Write($buffer, 0, $count)
        }
        return ,$ms.ToArray()
    }
    finally {
        if ($stream) { $stream.Dispose() }
        if ($response) { $response.Dispose() }
        $ms.Dispose()
    }
}
function Get-SignedFeed {
    $last = 'No feed could be verified.'
    foreach ($base in @($FeedRoot, $FallbackRoot)) {
        try {
            [byte[]]$data = Get-Remote ($base + 'latest.json') 524288
            $raw = [Text.Encoding]::UTF8.GetString($data) | ConvertFrom-Json
            $payload = [Convert]::FromBase64String([string]$raw.payload)
            $signature = [Convert]::FromBase64String([string]$raw.signature)
            if ($signature.Length -ne 256 -or $payload.Length -gt 262144 -or $payload.Length -lt 100) {
                throw 'Signed feed envelope size error.'
            }
            if ((Hash-Bytes $payload 'SHA256') -cne $ManifestPayloadSha) {
                throw 'Not the pinned HOJA Board 1.66.33 manifest.'
            }
            $rsa = New-Object Security.Cryptography.RSACryptoServiceProvider
            try {
                $rsa.FromXmlString($PublicKeyXml)
                if ($rsa.KeySize -ne 2048 -or -not $rsa.VerifyData($payload, 'SHA256', $signature)) {
                    throw 'Release signature verification failed.'
                }
            }
            finally { $rsa.Dispose() }
            $manifest = [Text.Encoding]::UTF8.GetString($payload) | ConvertFrom-Json
            if ($manifest.version -cne $Version -or $manifest.schema -cne 'TT-RUNTIME-SNAPSHOT-1' -or
                $manifest.channel -cne 'stable' -or $manifest.kernel -ne 1) {
                throw 'Unexpected manifest contract.'
            }
            if (@($manifest.files).Count -lt 38 -or @($manifest.files).Count -gt 128) {
                throw 'Unexpected signed file inventory.'
            }
            return $manifest
        }
        catch { $last = $_.Exception.Message }
    }
    throw ('Signed release feed cannot be verified: ' + $last)
}
function Get-VerifiedBlob([string]$Name, [int]$Length, [string]$Sha) {
    $last = 'Could not fetch blob.'
    foreach ($base in @($FeedRoot, $FallbackRoot)) {
        try {
            [byte[]]$data = Get-Remote ($base + 'blobs/' + $Sha + '.bin') $Length
            if ($data.Length -ne $Length -or (Hash-Bytes $data 'SHA256') -cne $Sha) {
                throw ('Signed file checksum mismatch: ' + $Name)
            }
            return ,$data
        }
        catch { $last = $_.Exception.Message }
    }
    throw ('Could not verify ' + $Name + ': ' + $last)
}
function Write-Json([string]$Path, $Value) {
    $utf8 = New-Object Text.UTF8Encoding($false)
    $data = ConvertTo-Json -InputObject $Value -Depth 6 -Compress
    [IO.File]::WriteAllText($Path, $data, $utf8)
}
function Recover-Pending {
    if (-not (Test-Path -LiteralPath $Pending)) { return }
    Assert-Plain $Pending
    $info = Get-Content -LiteralPath $Pending -Raw -Encoding UTF8 | ConvertFrom-Json
    if ($info.schema -ne 1 -or [string]$info.backupFolder -cnotmatch '^hoja-manual-backup-[a-f0-9]{32}$') {
        throw 'Unrecognized previous manual installation transaction; no files changed.'
    }
    $backupDir = Join-Path $Destination ([string]$info.backupFolder)
    Assert-Plain $backupDir
    foreach ($record in @($info.files)) {
        $name = [string]$record.name
        if ($name -cnotmatch '^[a-zA-Z0-9][a-zA-Z0-9._-]*$') { throw 'Invalid recovery file name.' }
        $target = Join-Path $Destination $name
        Assert-Plain $target
        if ($record.existed -eq $true) {
            $saved = Join-Path $backupDir $name
            Assert-Plain $saved
            if (-not (Test-Path -LiteralPath $saved)) { throw ('Missing backup: ' + $name) }
            $temp = Join-Path $Destination ($name + '.restore.tmp')
            [IO.File]::Copy($saved, $temp, $true)
            if (Test-Path -LiteralPath $target) {
                # Windows PowerShell 5.1/.NET Framework needs a valid backup path for File.Replace.
                # Leave the previously verified backup file untouched for recovery retries.
                $preRecovery = Join-Path $backupDir ($name + '.pre-recovery-' + [guid]::NewGuid().ToString('N'))
                [IO.File]::Replace($temp, $target, $preRecovery)
            }
            else { [IO.File]::Move($temp, $target) }
        }
        elseif (Test-Path -LiteralPath $target) { [IO.File]::Delete($target) }
        $temp = $target + '.hoja-new'
        if (Test-Path -LiteralPath $temp -PathType Leaf) { [IO.File]::Delete($temp) }
    }
    [IO.File]::Delete($Pending)
    Write-Host 'Previous interrupted manual installation was restored.'
}
function Assert-Closed {
    # Never close or kill programs automatically; a running board can hold program files open.
    $tcp = New-Object Net.Sockets.TcpClient
    try {
        $async = $tcp.BeginConnect('127.0.0.1', 17439, $null, $null)
        try {
            if ($async.AsyncWaitHandle.WaitOne(500) -and $tcp.Connected) {
                throw 'HOJA Board service is running. Close HOJA Board and retry.'
            }
        }
        finally { $async.AsyncWaitHandle.Close() }
    }
    finally { $tcp.Close() }
    foreach ($p in @(Get-CimInstance Win32_Process -Filter "Name='msedge.exe' OR Name='chrome.exe'" -ErrorAction Stop)) {
        $cmd = [string]$p.CommandLine
        if ($cmd -and ($cmd.IndexOf((Join-Path $Destination 'EdgeProfile'), [StringComparison]::OrdinalIgnoreCase) -ge 0 -or
                       $cmd.IndexOf((Join-Path $Destination 'ChromeProfile'), [StringComparison]::OrdinalIgnoreCase) -ge 0)) {
            throw 'HOJA Board browser is open. Close HOJA Board and retry.'
        }
    }
    foreach ($marker in @('r8-transaction\pending.json', 'stable-pilot-rollback\pending.json')) {
        if (Test-Path -LiteralPath (Join-Path $Destination $marker)) {
            throw 'An existing update recovery is pending. Do not override it with this installer.'
        }
    }
}
function Update-HojaShortcut {
    if ($NoShortcut) { return }
    $desktop = [Environment]::GetFolderPath('Desktop')
    if (-not $desktop) { throw 'Desktop folder could not be resolved.' }
    $shell = New-Object -ComObject WScript.Shell
    $canonical = Join-Path $desktop '호자보드.lnk'
    $stagedLink = Join-Path $desktop ('hoja-' + [guid]::NewGuid().ToString('N') + '.lnk')
    try {
        # Rebuild, never skip an existing shortcut. A stable launcher always follows future updates.
        $sc = $shell.CreateShortcut($stagedLink)
        $sc.TargetPath = (Join-Path $env:SystemRoot 'System32\WindowsPowerShell\v1.0\powershell.exe')
        $sc.Arguments = '-NoProfile -ExecutionPolicy Bypass -File "' + (Join-Path $Destination 'launch.ps1') + '"'
        $sc.WorkingDirectory = $Destination
        $sc.Description = '호자보드 (설치된 최신 버전 자동 실행)'
        $icon = Join-Path $Destination 'hoja.ico'
        if (Test-Path -LiteralPath $icon) { $sc.IconLocation = $icon + ',0' }
        $sc.Save()
        if (-not (Test-Path -LiteralPath $stagedLink -PathType Leaf)) { throw 'Could not create the HOJA Board shortcut.' }
        Move-Item -LiteralPath $stagedLink -Destination $canonical -Force -ErrorAction Stop
    }
    finally { Remove-Item -LiteralPath $stagedLink -Force -ErrorAction SilentlyContinue }

    # Remove only recognizable legacy HOJA/Teacher Tools Desktop launcher shortcuts.
    # Do not touch arbitrary links or other software on the PC.
    $otherFolders = @($desktop, [Environment]::GetFolderPath('CommonDesktopDirectory'),
      [Environment]::GetFolderPath('Startup')) | Where-Object { $_ -and (Test-Path -LiteralPath $_) } | Select-Object -Unique
    foreach ($folder in $otherFolders) {
        foreach ($item in @(Get-ChildItem -LiteralPath $folder -Filter '*.lnk' -File -ErrorAction SilentlyContinue)) {
            if ($item.FullName -ieq $canonical) { continue }
            $name = $item.Name
            $candidate = $name -match '^(?i:호자보드(?: \(.*\))?|HOJA Board(?: .*)?|Teacher Tools Desktop)\.lnk$'
            if (-not $candidate) { continue }
            try {
                $old = $shell.CreateShortcut($item.FullName)
                $command = [string]$old.TargetPath + ' ' + [string]$old.Arguments
                if ($command.IndexOf('TeacherToolsLocal',[StringComparison]::OrdinalIgnoreCase) -lt 0 -and
                    $command.IndexOf('TeacherToolsDesktop',[StringComparison]::OrdinalIgnoreCase) -lt 0) { continue }
                Remove-Item -LiteralPath $item.FullName -Force -ErrorAction Stop
                Write-Host ('Removed outdated HOJA shortcut: ' + $item.FullName)
            } catch { Write-Host ('Legacy shortcut cleanup skipped: ' + $item.FullName) -ForegroundColor Yellow }
        }
    }
    Write-Host ('Shortcut refreshed: ' + $canonical)
}

$hadPending = $false
try {
    if ($env:OS -cne 'Windows_NT') { throw 'This installer only runs on Windows.' }
    if (-not $env:LOCALAPPDATA -or -not $env:TEMP) { throw 'Windows user profile paths are unavailable.' }
    Assert-Plain $Destination
    if (Test-Path -LiteralPath $Destination) {
        Assert-Closed
        Recover-Pending
    }
    $currentRelease = Join-Path $Destination 'release.json'
    if (Test-Path -LiteralPath $currentRelease) {
        Assert-Plain $currentRelease
        $installed = Get-Content -LiteralPath $currentRelease -Raw -Encoding UTF8 | ConvertFrom-Json
        if ($installed.version -and ([version]([string]$installed.version)) -gt ([version]$Version)) {
            throw 'A newer version is installed. Downgrading is not allowed.'
        }
        Write-Host ('Existing installation: ' + [string]$installed.version + ' (user data will be preserved)')
    }
    Write-Host ('Getting signed HOJA Board ' + $Version + ' manifest...')
    $manifest = Get-SignedFeed
    $names = [Collections.Generic.HashSet[string]]::new([StringComparer]::OrdinalIgnoreCase)
    $total = [long]0
    foreach ($f in @($manifest.files)) {
        $name = [string]$f.name
        if ($name -cnotmatch '^[a-zA-Z0-9][a-zA-Z0-9._-]*$' -or $name -in @('launch.ps1', 'r8-kernel.ps1', 'update-public.xml') -or -not $names.Add($name)) {
            throw ('Unexpected signed file name: ' + $name)
        }
        if ([string]$f.sha256 -cnotmatch '^[a-f0-9]{64}$' -or $f.bytes -lt 1 -or $f.bytes -gt $MaxFile) {
            throw ('Invalid signed file metadata: ' + $name)
        }
        $total += [long]$f.bytes
        if ($total -gt $MaxTotal) { throw 'Signed program inventory is too large.' }
    }
    if (-not $names.Contains('release.json') -or -not $names.Contains('dashboard.html') -or
        -not $names.Contains('server.ps1') -or -not $names.Contains('board-launch.ps1') -or
        -not $names.Contains('runtime.ps1')) { throw 'Required signed programs missing.' }
    New-Item -Path $Working -ItemType Directory -Force | Out-Null
    $staged = Join-Path $Working 'verified'
    New-Item -Path $staged -ItemType Directory | Out-Null
    $number = 0
    foreach ($f in @($manifest.files)) {
        $number++
        Write-Host ('Downloading and checking ' + $number + '/' + @($manifest.files).Count + ': ' + $f.name)
        [byte[]]$bytes = Get-VerifiedBlob ([string]$f.name) ([int]$f.bytes) ([string]$f.sha256)
        [IO.File]::WriteAllBytes((Join-Path $staged ([string]$f.name)), $bytes)
    }
    # The signed manifest names the programs. The unchanging R8 launcher/kernel are pinned to a reviewed Git commit.
    foreach ($bootstrap in @(
        @{name='launch.ps1'; sha='d6f0289779d6fcdd2bad5a2ad79925913f1fb9c7'},
        @{name='r8-kernel.ps1'; sha='ecb4eaa4d40c68b4b20bcb3b1e1d7801c3a836e0'}
    )) {
        $name = [string]$bootstrap.name
        Write-Host ('Downloading fixed update launcher: ' + $name)
        [byte[]]$bytes = Get-Remote ($BootstrapRoot + $name) 65536
        if ((Git-Blob-Sha $bytes) -cne [string]$bootstrap.sha) { throw ('Fixed launcher hash mismatch: ' + $name) }
        [IO.File]::WriteAllBytes((Join-Path $staged $name), $bytes)
    }
    [IO.File]::WriteAllText((Join-Path $staged 'update-public.xml'), $PublicKeyXml, ([Text.UTF8Encoding]::new($false)))
    $r = Get-Content -LiteralPath (Join-Path $staged 'release.json') -Raw -Encoding UTF8 | ConvertFrom-Json
    if ($r.version -cne $Version -or $r.channel -cne 'stable' -or $r.runtimeProtocol -ne 1 -or
        $r.updateMode -cne 'auto-pilot') { throw 'Signed release.json does not match the intended version.' }

    # Only after every byte has been verified do we stage backups and replace program files.
    if (-not (Test-Path -LiteralPath $Destination)) {
        New-Item -Path $Destination -ItemType Directory | Out-Null
    }
    Assert-Closed
    $backupName = 'hoja-manual-backup-' + [guid]::NewGuid().ToString('N')
    $backup = Join-Path $Destination $backupName
    New-Item -Path $backup -ItemType Directory | Out-Null
    $records = @()
    $allNames = @(@($manifest.files | ForEach-Object { [string]$_.name }) + @('launch.ps1', 'r8-kernel.ps1', 'update-public.xml'))
    foreach ($name in $allNames) {
        $target = Join-Path $Destination $name
        Assert-Plain $target
        $exists = Test-Path -LiteralPath $target -PathType Leaf
        if (Test-Path -LiteralPath $target -PathType Container) { throw ('Program path is a directory: ' + $name) }
        if ($exists) { [IO.File]::Copy($target, (Join-Path $backup $name), $false) }
        $records += @{name=$name; existed=[bool]$exists}
    }
    # Marker is recorded before first file replacement; rerun recovers after power interruption.
    Write-Json $Pending @{schema=1; backupFolder=$backupName; files=@($records); version=$Version}
    $hadPending = $true
    foreach ($name in $allNames) {
        $dst = Join-Path $Destination $name
        $src = Join-Path $staged $name
        $temp = Join-Path $Destination ($name + '.hoja-new')
        Assert-Plain $temp
        if (Test-Path -LiteralPath $temp) { throw ('A stale temporary file exists: ' + $name) }
        [IO.File]::Copy($src, $temp, $false)
        if (Test-Path -LiteralPath $dst) {
            # Keep the original copy in $backup intact; do not pass $null as backup path.
            $displaced = Join-Path $backup ($name + '.pre-install-' + [guid]::NewGuid().ToString('N'))
            [IO.File]::Replace($temp, $dst, $displaced)
        }
        else { [IO.File]::Move($temp, $dst) }
    }
    foreach ($f in @($manifest.files)) {
        $name = [string]$f.name
        if ((Hash-File (Join-Path $Destination $name)) -cne [string]$f.sha256) {
            throw ('Post-install checksum mismatch: ' + $name)
        }
    }
    foreach ($bootstrap in @(
        @{name='launch.ps1'; sha='d6f0289779d6fcdd2bad5a2ad79925913f1fb9c7'},
        @{name='r8-kernel.ps1'; sha='ecb4eaa4d40c68b4b20bcb3b1e1d7801c3a836e0'}
    )) {
        if ((Git-Blob-Sha ([IO.File]::ReadAllBytes((Join-Path $Destination $bootstrap.name)))) -cne $bootstrap.sha) {
            throw ('Installed launcher checksum mismatch: ' + $bootstrap.name)
        }
    }
    [IO.File]::Delete($Pending)
    $hadPending = $false

    # Exactly one canonical desktop shortcut, regenerated on every successful install.
    Update-HojaShortcut
    Write-Host ''
    Write-Host ('SUCCESS: HOJA Board ' + $Version + ' installed.') -ForegroundColor Green
    Write-Host ('Install folder: ' + $Destination)
    Write-Host ('Previous program backups: ' + $backup)
    Write-Host 'Your school settings, browser profiles, coins, roster, and personal files were not deleted.'
    Write-Host 'Launch with the single desktop shortcut: 호자보드.lnk' 
}
catch {
    $reason = $_.Exception.Message
    Write-Host ('INSTALLATION FAILED: ' + $reason) -ForegroundColor Red
    if ($hadPending) {
        try { Recover-Pending; Write-Host 'Original program files restored.' }
        catch { Write-Host ('RECOVERY NEEDED: ' + $_.Exception.Message) -ForegroundColor Yellow }
    }
    exit 1
}
finally {
    if (Test-Path -LiteralPath $Working) {
        try { Remove-Item -LiteralPath $Working -Recurse -Force -ErrorAction Stop }
        catch { Write-Host ('Temporary download folder remains: ' + $Working) }
    }
}
